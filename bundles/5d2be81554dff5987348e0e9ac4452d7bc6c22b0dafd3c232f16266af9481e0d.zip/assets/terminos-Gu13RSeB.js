import{r as e}from"./chunk-QTnfLwEv.js";import{n as t,t as n}from"./jsx-runtime-KLUqzItW.js";import{t as r}from"./link-BhysfqGo.js";import{n as i}from"./createLucideIcon-Czsbm9hR.js";import{t as a}from"./arrow-left-DDKPiyqp.js";import{n as o,t as s}from"./LegalMarkdown-CPubzBqv.js";var c=e(t()),l=`Publicado em https://bless883fm.app/terminos. A página mostra este arquivo: espanhol entre o 1º e o 2º \`---\`, inglês depois do 2º.
Preenchido em 14/10/2026 com os dados públicos da Genesis Radio Network, Inc. (vendedora do app atual na App Store; endereço do estúdio no FCC). Revisão jurídica recomendada.

---

# Términos de Uso de Bless 88.3 FM

**Vigentes desde:** 14 de octubre de 2026

## 1. Aceptación

Estos términos son un acuerdo entre usted y Genesis Radio Network, Inc. ("Bless 88.3 FM" o "nosotros"). Valen para la app Bless 88.3 FM (iOS y Android) y para el sitio web bless883fm.app. Aquí llamamos "la app" a los dos.

Al usar la app, usted acepta estos términos y nuestra Política de Privacidad: https://bless883fm.app/privacidad. Si no está de acuerdo, no use la app.

## 2. Cuentas y uso de la app

- Debe tener al menos 13 años. Si es menor de edad donde vive, use la app con permiso de su padre, madre o tutor.
- Puede usar parte de la app sin cuenta. Para otras funciones necesita una cuenta. Puede crearla con su correo y una contraseña, o entrar con Google o con Apple.
- Su cuenta es personal. Cuide su contraseña. Si cree que otra persona usa su cuenta, escríbanos.
- Use la app de buena fe. No intente dañarla, entrar en cuentas ajenas ni copiar su contenido con programas automáticos.
- Podemos suspender o cerrar una cuenta que no cumpla estos términos.

## 3. Reglas del mural de oración

El mural es un lugar para pedir oración y orar por otros. Antes de su primer pedido, le pedimos que acepte estas reglas.

**No toleramos el contenido ofensivo ni a los usuarios abusivos.** En el mural no se permite:

- acoso, amenazas o burlas;
- odio contra personas o grupos por su raza, origen, religión, sexo, edad, discapacidad u otra condición;
- contenido sexual;
- spam o mensajes repetidos;
- datos personales de otras personas (nombre completo, teléfono, dirección o detalles de salud) sin su permiso. Puede pedir oración por alguien sin decir quién es, por ejemplo: "por mi hermana";
- promoción comercial: anuncios, ventas, enlaces a negocios o pedidos de dinero;
- nada que sea ilegal.

**Revisión previa.** Cada pedido se revisa antes de publicarse. Solo aparece en el mural después de que un moderador o un pastor lo aprueba. Podemos no aprobar un pedido que no cumpla las reglas.

**Denunciar.** Cada pedido tiene un botón para denunciarlo. Revisamos cada denuncia en un plazo máximo de 24 horas.

**Bloquear.** Puede bloquear al autor de un pedido. Así, usted ya no verá sus pedidos.

**Si alguien no cumple.** Quitamos el contenido. Además, podemos silenciar al autor o suspender su cuenta.

Estas reglas valen también para los pedidos anónimos y para los saludos que usted envía al estudio.

## 4. La app no es un servicio de emergencia

Si usted u otra persona está en peligro:

- **En Estados Unidos, llame al 911.**
- Si piensa en hacerse daño o vive una crisis emocional, **llame o envíe un mensaje de texto al 988**. Para hablar en español, al llamar oprima 2.
- **Fuera de Estados Unidos, llame al número de emergencias de su país.**

No use el mural, los saludos ni Bless AI para pedir ayuda urgente. Los pedidos se revisan antes de publicarse y la respuesta puede tardar.

## 5. Bless AI

- Bless AI le permite conversar, por texto o por voz, con "discípulos": personajes bíblicos recreados con inteligencia artificial. No son las personas reales, y sus respuestas no son la Biblia.
- Bless AI no es un pastor, ni un médico, ni un consejero o psicólogo. No da consejo médico, legal ni financiero.
- Puede equivocarse, también en temas de fe. Compare siempre con la Biblia y hable con su pastor o su iglesia.
- No lo use en una emergencia (vea la sección 4).
- Antes del primer uso le pedimos permiso, porque sus mensajes y su voz se envían a OpenAI (por medio de Lovable AI Gateway) y el texto de las respuestas se envía a ElevenLabs. La Política de Privacidad explica los detalles.
- La memoria pastoral es opcional.
- Puede haber un límite de uso por día.
- No use Bless AI para crear contenido ofensivo o ilegal. Si una respuesta le parece ofensiva o equivocada, avísenos a info@bless883fm.com.

## 6. Donaciones

- Las donaciones son voluntarias.
- Se hacen en una página de Stripe, fuera de la app. Stripe procesa el pago con sus propias condiciones.
- Donar no le da nada a cambio en la app: no abre funciones ni contenido. Todo en la app es gratis.
- Si tiene un problema con una donación, escríbanos.

## 7. Eliminar su cuenta

Puede eliminar su cuenta cuando quiera, en la app (en Más › Cuenta) o en la web: https://bless883fm.app/cuenta/eliminar. Se borran sus datos personales, sus fotos, sus audios y su acceso, en todos sus dispositivos. No se puede deshacer. La Política de Privacidad explica los detalles.

## 8. Su contenido y el nuestro

- Lo que usted publica o envía (pedidos, testimonios, audios, saludos y mensajes) sigue siendo suyo.
- Publique solo lo que es suyo o lo que tiene permiso para compartir.
- Al publicar en el mural, nos da un permiso (licencia) gratuito, no exclusivo y válido en todo el mundo para guardar, mostrar y reproducir su contenido en la app, y para que nuestro equipo lo revise, ore y responda. Este permiso termina cuando su contenido se borra.
- Al enviar un saludo, nos permite leerlo o reproducirlo al aire.
- Los programas, textos y audios de la app, y el nombre y la marca Bless 88.3 FM, son nuestros o de sus dueños. Puede usarlos solo para uso personal, sin fines comerciales.

## 9. Contenido y servicios de otros

La app muestra contenido de otros oyentes y enlaces a servicios de otras empresas, como Spotify y Stripe. No respondemos por lo que publican otros oyentes ni por esos servicios. Cada servicio tiene sus propias reglas.

## 10. Lo que no garantizamos y límite de responsabilidad

- Ofrecemos la app tal como está y según esté disponible. Hacemos lo posible para que la radio y la app funcionen, pero puede haber cortes o errores.
- El contenido de la app, incluidas las respuestas de los pastores y de Bless AI, es apoyo espiritual. No reemplaza a un médico, un psicólogo, un abogado ni otro profesional.
- En la medida en que la ley lo permita, no respondemos por daños indirectos, ni por daños causados por contenido de otros oyentes, por respuestas de Bless AI o por fallas del servicio.
- Si la ley nos hace responsables, nuestra responsabilidad total no pasará de US$ 100.
- Nada en estos términos le quita derechos que la ley de su país no permite quitar.

## 11. Cambios en estos términos

Podemos cambiar estos términos. Si el cambio es importante, le avisaremos en la app antes de que empiece a valer. Si sigue usando la app después, acepta los nuevos términos.

## 12. Ley aplicable

Estos términos se rigen por las leyes del estado de Florida y las leyes federales de Estados Unidos. Cualquier disputa se resolverá en los tribunales del condado de Broward, Florida. Si usted vive en otro país, mantiene los derechos que la ley de su país le da como consumidor.

## 13. Otros puntos

- Si una parte de estos términos no vale, el resto sigue valiendo.
- Si descargó la app en la App Store o en Google Play, también valen las reglas de esa tienda. Apple y Google no son parte de estos términos ni responden por la app.
- Estos términos están en español y en inglés. Si hay diferencias, vale la versión en español.

## 14. Contacto

- Genesis Radio Network, Inc.
- Dirección: 3401 SW 160th Avenue, Suite 403, Miramar, FL 33027, Estados Unidos
- Correo: info@bless883fm.com

En la app también encuentra nuestro correo y el teléfono pastoral.

---

# Bless 88.3 FM Terms of Use

**Effective date:** October 14, 2026

## 1. Acceptance

These terms are an agreement between you and Genesis Radio Network, Inc. ("Bless 88.3 FM" or "we"). They cover the Bless 88.3 FM app (iOS and Android) and the website bless883fm.app. Here we call both "the app."

By using the app, you accept these terms and our Privacy Policy: https://bless883fm.app/privacidad. If you do not agree, do not use the app.

## 2. Accounts and use of the app

- You must be at least 13 years old. If you are a minor where you live, use the app with permission from your parent or guardian.
- You can use part of the app without an account. For other features you need an account. You can create one with your email and a password, or sign in with Google or Apple.
- Your account is personal. Protect your password. If you think someone else is using your account, write to us.
- Use the app in good faith. Do not try to harm it, get into other people's accounts, or copy its content with automated programs.
- We may suspend or close an account that does not follow these terms.

## 3. Prayer wall rules

The prayer wall is a place to ask for prayer and to pray for others. Before your first request, we ask you to accept these rules.

**We have zero tolerance for objectionable content and abusive users.** On the prayer wall, you may not post:

- harassment, threats or mockery;
- hate against people or groups because of their race, origin, religion, sex, age, disability or any other condition;
- sexual content;
- spam or repeated messages;
- other people's personal information (full name, phone number, address or health details) without their permission. You can ask for prayer for someone without saying who they are, for example: "for my sister";
- commercial promotion: ads, sales, links to businesses or requests for money;
- anything illegal.

**Review before posting.** Every request is reviewed before it is published. It appears on the wall only after a moderator or a pastor approves it. We may decline a request that does not follow the rules.

**Reporting.** Every request has a button to report it. We review every report within 24 hours.

**Blocking.** You can block the author of a request. Then you will no longer see their requests.

**If someone breaks the rules.** We remove the content. We may also mute the author or suspend their account.

These rules also apply to anonymous requests and to the saludos you send to the studio.

## 4. The app is not an emergency service

If you or someone else is in danger:

- **In the United States, call 911.**
- If you are thinking about hurting yourself or are in an emotional crisis, **call or text 988**. For Spanish, press 2 when you call.
- **Outside the United States, call your country's emergency number.**

Do not use the prayer wall, saludos or Bless AI to ask for urgent help. Requests are reviewed before they are published, and a reply may take time.

## 5. Bless AI

- Bless AI lets you talk, by text or by voice, with "disciples": Bible characters recreated with artificial intelligence. They are not the real people, and their answers are not the Bible.
- Bless AI is not a pastor, a doctor, a counselor or a psychologist. It does not give medical, legal or financial advice.
- It can make mistakes, including about matters of faith. Always compare with the Bible and talk with your pastor or your church.
- Do not use it in an emergency (see section 4).
- Before your first use, we ask for your permission, because your messages and your voice are sent to OpenAI (through the Lovable AI Gateway) and the text of the answers is sent to ElevenLabs. The Privacy Policy explains the details.
- Pastoral memory is optional.
- There may be a daily usage limit.
- Do not use Bless AI to create offensive or illegal content. If an answer seems offensive or wrong to you, let us know at info@bless883fm.com.

## 6. Donations

- Donations are voluntary.
- They are made on a Stripe page, outside the app. Stripe processes the payment under its own terms.
- Donating does not give you anything in return in the app: it does not unlock features or content. Everything in the app is free.
- If you have a problem with a donation, write to us.

## 7. Deleting your account

You can delete your account at any time, in the app (in More › Account) or on the web: https://bless883fm.app/cuenta/eliminar. Your personal data, your photos, your audio and your sign-in are deleted on all your devices. It cannot be undone. The Privacy Policy explains the details.

## 8. Your content and ours

- What you post or send (requests, testimonies, audio, saludos and messages) is still yours.
- Post only what is yours or what you have permission to share.
- When you post on the prayer wall, you give us a free, non-exclusive, worldwide permission (license) to store, show and play your content in the app, and to let our team review it, pray for it and reply. This permission ends when your content is deleted.
- When you send a saludo, you allow us to read it or play it on the air.
- The programs, texts and audio in the app, and the Bless 88.3 FM name and brand, belong to us or to their owners. You may use them only for personal, non-commercial use.

## 9. Content and services from others

The app shows content from other listeners and links to services from other companies, such as Spotify and Stripe. We are not responsible for what other listeners post or for those services. Each service has its own rules.

## 10. What we do not guarantee and limits on our liability

- We offer the app as it is and as available. We do our best to keep the radio and the app working, but there may be outages or errors.
- The content of the app, including the replies from pastors and from Bless AI, is spiritual support. It does not replace a doctor, a psychologist, a lawyer or any other professional.
- To the extent the law allows, we are not responsible for indirect damages, or for damages caused by other listeners' content, by Bless AI answers or by service failures.
- If the law makes us responsible, our total liability will not exceed US$ 100.
- Nothing in these terms takes away rights that the law of your country does not allow to be taken away.

## 11. Changes to these terms

We may change these terms. If the change is important, we will tell you in the app before it takes effect. If you keep using the app after that, you accept the new terms.

## 12. Governing law

These terms are governed by the laws of the State of Florida and the federal laws of the United States. Any dispute will be resolved in the courts of Broward County, Florida. If you live in another country, you keep the rights that your country's law gives you as a consumer.

## 13. Other points

- If one part of these terms is not valid, the rest still applies.
- If you downloaded the app from the App Store or Google Play, that store's rules also apply. Apple and Google are not parties to these terms and are not responsible for the app.
- These terms are in Spanish and in English. If they differ, the Spanish version applies.

## 14. Contact

- Genesis Radio Network, Inc.
- Address: 3401 SW 160th Avenue, Suite 403, Miramar, FL 33027, United States
- Email: info@bless883fm.com

You can also find our email and our pastoral phone number in the app.
`,u=n();function d(e){return e.split(/(\*\*[^*]+\*\*)/g).map((e,t)=>e.startsWith(`**`)&&e.endsWith(`**`)?(0,u.jsx)(`strong`,{className:`text-foreground`,children:e.slice(2,-2)},t):(0,u.jsx)(c.Fragment,{children:e},t))}function f(){let{t:e,i18n:t}=i(),n=o(l,t.language);if(n.trim()&&!n.includes(`<PREENCHER`))return(0,u.jsxs)(`div`,{className:`px-5 pt-6 pb-10`,children:[(0,u.jsxs)(r,{to:`/mas`,className:`inline-flex items-center gap-1.5 text-[0.875rem] text-muted-foreground`,children:[(0,u.jsx)(a,{size:16}),` `,e(`deleteAccount.back`)]}),(0,u.jsx)(s,{text:n})]});let c=e(`terms.md`,{returnObjects:!0}),f=[],p=[],m=()=>{if(p.length){let e=p;f.push((0,u.jsx)(`ul`,{className:`mt-2 list-disc pl-5 space-y-1.5`,children:e.map((e,t)=>(0,u.jsx)(`li`,{children:d(e)},t))},`l${f.length}`)),p=[]}};for(let e of Array.isArray(c)?c:[]){if(e.startsWith(`- `)){p.push(e.slice(2));continue}m(),e.trim()&&(e.startsWith(`## `)?f.push((0,u.jsx)(`h2`,{className:`mt-6 text-[1.0625rem] font-semibold text-foreground`,children:e.slice(3)},f.length)):f.push((0,u.jsx)(`p`,{className:`mt-3`,children:d(e)},f.length)))}return m(),(0,u.jsxs)(`div`,{className:`px-5 pt-6 pb-10`,children:[(0,u.jsxs)(r,{to:`/mas`,className:`inline-flex items-center gap-1.5 text-[0.875rem] text-muted-foreground`,children:[(0,u.jsx)(a,{size:16}),` `,e(`deleteAccount.back`)]}),(0,u.jsx)(`h1`,{className:`mt-4 font-brand text-[1.625rem] font-bold text-foreground`,children:e(`terms.title`)}),(0,u.jsx)(`div`,{className:`text-[0.875rem] leading-relaxed text-muted-foreground`,children:f})]})}export{f as component};