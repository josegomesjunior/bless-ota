const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/client-YvUp_M0W.js","assets/chunk-QTnfLwEv.js","assets/preload-helper-zJ_50EbN.js"])))=>i.map(i=>d[i]);
import{t as e}from"./preload-helper-zJ_50EbN.js";import{a as t,c as n,i as r,l as i,m as a,o,s,u as c}from"./index-B6lXl0ld.js";var l={natividad:{parentQuestion:{es:`¿Dónde, en tu vida hoy, necesitas recordar que Dios eligió venir cerca — incluso a lo más humilde de ti?`,en:`Where in your life today do you need to remember that God chose to come close — even to the humblest parts of you?`},familyPrayer:{es:`Jesús, gracias por venir a nosotros.
Hazte pequeñito en nuestra casa esta noche.
Que tu paz duerma con nosotros.
Amén.`,en:`Jesus, thank you for coming to us.
Make yourself small in our home tonight.
May your peace sleep with us.
Amen.`}},bautismo:{parentQuestion:{es:`¿Qué voz necesitas silenciar para volver a oír al Padre decirte: 'Tú eres mi hijo amado'?`,en:`What voice do you need to quiet so you can hear the Father say again: 'You are my beloved child'?`},familyPrayer:{es:`Padre, somos tus hijos amados.
Espíritu Santo, ven sobre esta casa.
Jesús, camina con nosotros.
Amén.`,en:`Father, we are your beloved children.
Holy Spirit, come over this home.
Jesus, walk with us.
Amen.`}},"sobre-el-agua":{parentQuestion:{es:`¿En qué área hoy estás mirando las olas más que a Jesús? ¿Dónde necesitas oír 'ánimo, soy yo'?`,en:`Where today are you looking at the waves more than at Jesus? Where do you need to hear 'Take courage, it is I'?`},familyPrayer:{es:`Jesús, tú caminas hacia nosotros.
En nuestro miedo, tómanos la mano.
Que tu voz calme esta noche.
Amén.`,en:`Jesus, you walk toward us.
In our fear, take our hand.
May your voice calm this night.
Amen.`}},"los-5000":{parentQuestion:{es:`¿Qué 'cinco panes y dos peces' tienes hoy — pequeño, insuficiente — que Jesús te está pidiendo poner en sus manos?`,en:`What 'five loaves and two fish' do you have today — small, not enough — that Jesus is asking you to place in his hands?`},familyPrayer:{es:`Jesús, tomamos lo poquito que tenemos.
Bendícelo en tus manos.
Que alcance para nosotros y para otros.
Amén.`,en:`Jesus, we take the little we have.
Bless it in your hands.
May it be enough for us and for others.
Amen.`}},sanidad:{parentQuestion:{es:`¿Qué herida vieja tienes que quiere colarse entre la multitud para tocar el manto de Jesús esta noche?`,en:`What old wound in you wants to slip through the crowd tonight and touch the edge of Jesus' cloak?`},familyPrayer:{es:`Jesús, tocamos hoy tu manto.
Mira nuestras heridas con ternura.
Danos tu paz y tu salud.
Amén.`,en:`Jesus, tonight we touch your cloak.
Look at our wounds with tenderness.
Give us your peace and your health.
Amen.`}},"ultima-cena":{parentQuestion:{es:`¿A quién de tu casa necesitas 'lavarle los pies' esta semana — con paciencia, escucha, un perdón?`,en:`Whose feet in your home do you need to 'wash' this week — with patience, listening, or forgiveness?`},familyPrayer:{es:`Jesús, gracias por partir el pan por nosotros.
Enséñanos a servirnos con amor.
Que tu mesa sea nuestra mesa.
Amén.`,en:`Jesus, thank you for breaking bread for us.
Teach us to serve one another with love.
May your table be our table.
Amen.`}},resurreccion:{parentQuestion:{es:`¿Qué sueño, relación o parte de ti sientes 'en el sepulcro'? ¿Puedes creer, esta noche, que Jesús vive y todavía llama tu nombre?`,en:`What dream, relationship, or part of you feels 'in the tomb'? Can you believe tonight that Jesus is alive and still calls your name?`},familyPrayer:{es:`Jesús resucitado, tú vives.
En lo que damos por muerto, llámanos por nombre.
Danos esperanza esta noche.
Amén.`,en:`Risen Jesus, you are alive.
In what we give up as dead, call us by name.
Give us hope tonight.
Amen.`}},"la-tormenta":{parentQuestion:{es:`¿En qué tormenta de tu vida necesitas oír hoy 'calla, enmudece'?`,en:`In what storm of your life do you need to hear today: 'Peace, be still'?`},familyPrayer:{es:`Jesús, tú estás en la barca con nosotros.
Habla a nuestras tormentas.
Danos tu calma esta noche.
Amén.`,en:`Jesus, you are in the boat with us.
Speak to our storms.
Give us your calm tonight.
Amen.`}}};function u(e=new Date){let t=Math.floor(e.getTime()/(1e3*60*60*24));return(Math.floor((t+3)/7)%8+8)%8}var d={disciples:{},adventures:{},familyNights:{}};function f(e){let a=t.find(t=>t.id===e);if(!a)return;let l=a.id;return{...a,toneOfVoice:i[l],testimony:n[l],canHelpWith:r[l],greeting:o[l],starters:s[l],voiceId:c[l],overridden:[]}}function p(e){let t=a.find(t=>t.id===e);return t?{...t,overridden:[]}:void 0}function m(e){let t=l[e];return t?{...t,overridden:[]}:void 0}function h(e){return e==null?!1:typeof e==`string`?e.trim().length>0:Array.isArray(e)?e.length>0:!0}function g(e,t){if(!t)return e;let n={...e,overridden:[]},r=(e,t,r)=>{h(t)&&(n[e]=t,n.overridden.push(r))};return r(`name`,t.name,`name`),r(`title`,t.title,`title`),r(`specialty`,t.specialty,`specialty`),r(`shortBio`,t.short_bio,`short_bio`),r(`personality`,t.personality,`personality`),r(`toneOfVoice`,t.tone_of_voice,`tone_of_voice`),r(`testimony`,t.testimony,`testimony`),r(`canHelpWith`,t.can_help_with,`can_help_with`),r(`camino`,t.camino,`camino`),r(`voiceId`,t.voice_id,`voice_id`),(h(t.greeting_adult)||h(t.greeting_kids))&&(n.greeting={adult:h(t.greeting_adult)?t.greeting_adult:e.greeting.adult,kids:h(t.greeting_kids)?t.greeting_kids:e.greeting.kids},h(t.greeting_adult)&&n.overridden.push(`greeting_adult`),h(t.greeting_kids)&&n.overridden.push(`greeting_kids`)),(h(t.starters_adult)||h(t.starters_kids))&&(n.starters={adult:h(t.starters_adult)?t.starters_adult:e.starters.adult,kids:h(t.starters_kids)?t.starters_kids:e.starters.kids},h(t.starters_adult)&&n.overridden.push(`starters_adult`),h(t.starters_kids)&&n.overridden.push(`starters_kids`)),n}function _(e,t){if(!t)return e;let n={...e,overridden:[]},r=(e,t,r)=>{h(t)&&(n[e]=t,n.overridden.push(r))};return r(`title`,t.title,`title`),r(`lessonTheme`,t.lesson_theme,`lesson_theme`),r(`keyVerse`,t.key_verse,`key_verse`),r(`keyVerseRef`,t.key_verse_ref,`key_verse_ref`),r(`scriptureRef`,t.scripture_ref,`scripture_ref`),r(`kidsVersion`,t.kids_version,`kids_version`),r(`retoldVersion`,t.retold_version,`retold_version`),r(`question`,t.quiz,`quiz`),n}function v(e,t){if(!t)return e;let n={...e,overridden:[]};return h(t.parent_question)&&(n.parentQuestion=t.parent_question,n.overridden.push(`parent_question`)),h(t.family_prayer)&&(n.familyPrayer=t.family_prayer,n.overridden.push(`family_prayer`)),n}function y(e,t){let n=f(e);if(n)return g(n,t.disciples[e])}function b(e,t){let n=p(e);if(n)return _(n,t.adventures[e])}function x(e,t){let n=m(e);if(n)return v(n,t.familyNights[e])}var S=d;function C(){return S}async function w(){let{supabase:t}=await e(async()=>{let{supabase:e}=await import(`./client-YvUp_M0W.js`).then(e=>e.t);return{supabase:e}},__vite__mapDeps([0,1,2])),[n,r,i]=await Promise.all([t.from(`disciples_content`).select(`*`).eq(`review_status`,`approved`),t.from(`adventures_content`).select(`*`).eq(`review_status`,`approved`),t.from(`family_night_content`).select(`*`).eq(`review_status`,`approved`)]),a={disciples:{},adventures:{},familyNights:{}};for(let e of n.data??[])a.disciples[e.disciple_id]=e;for(let e of r.data??[])a.adventures[e.adventure_id]=e;for(let e of i.data??[])a.familyNights[e.adventure_id]=e;return S=a,a}function T(e){return y(e,S)}function E(e){return b(e,S)}function D(e){return x(e,S)}function O(){return a.map(e=>b(e.id,S)).filter(e=>!!e)}export{O as a,w as c,u as d,E as i,C as l,f as n,T as o,m as r,D as s,p as t,l as u};