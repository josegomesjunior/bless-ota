import{t as e}from"./jsx-runtime-KLUqzItW.js";import{t}from"./link-BhysfqGo.js";import{n}from"./createLucideIcon-Czsbm9hR.js";import{t as r}from"./arrow-left-DDKPiyqp.js";import{n as i,t as a}from"./LegalMarkdown-rIuLCvl_.js";var o=`Publicado em https://bless883fm.app/privacidad. A página mostra este arquivo: espanhol entre o 1º e o 2º \`---\`, inglês depois do 2º.
Preenchido em 14/10/2026 com os dados públicos da Genesis Radio Network, Inc. (vendedora do app atual na App Store; endereço do estúdio no FCC). Revisão jurídica recomendada.

---

# Política de Privacidad de Bless 88.3 FM

**Vigente desde:** 14 de octubre de 2026

Esta política explica qué datos suyos usamos, para qué los usamos y qué puede hacer usted. Vale para la app Bless 88.3 FM (iOS y Android) y para el sitio web bless883fm.app. Aquí llamamos "la app" a los dos.

## En pocas palabras

- No vendemos sus datos.
- No mostramos anuncios.
- No usamos herramientas de publicidad ni de seguimiento de otras empresas.
- No rastreamos lo que usted hace en otras apps ni en otros sitios web.
- Antes de que use Bless AI por primera vez, le pedimos permiso, porque sus mensajes y su voz se envían a empresas de inteligencia artificial.
- Puede borrar su cuenta y sus datos desde la app o desde la web.

## 1. Quiénes somos

Bless 88.3 FM es una radio cristiana de Miami, Florida (Estados Unidos). La organización responsable de sus datos es:

- Genesis Radio Network, Inc.
- Dirección: 3401 SW 160th Avenue, Suite 403, Miramar, FL 33027, Estados Unidos
- Correo: info@bless883fm.com

En esta política, "nosotros" es la radio.

## 2. Qué datos recogemos y de dónde vienen

### Su cuenta

- Su correo y su contraseña. La contraseña se guarda como un código (hash) que nadie puede leer.
- Si entra con Google o con Apple, ellos nos dan su correo y un identificador de su cuenta.

### Su perfil

- Su nombre para mostrar y su idioma.
- Una foto, si usted decide subirla.
- La fecha en que aceptó las reglas del mural de oración.

### Mural de oración

- El texto de su pedido y su categoría.
- Si el pedido es público o privado, y si es anónimo.
- El nombre y la ciudad que usted escribe en el pedido.
- El audio, si graba uno.
- Las oraciones que usted hace por otros pedidos.
- Sus testimonios, cuando marca un pedido como respondido.
- Las denuncias y los bloqueos que usted hace.
- Las restricciones que la moderación pone a su cuenta, si las hay.

### Saludos

- Su nombre, su ciudad y su mensaje, en texto o en audio.
- Los saludos llegan al equipo de la radio, en el estudio. El locutor puede leerlos o ponerlos al aire.

### Bless AI

- El historial de sus conversaciones.
- Su memoria pastoral, si la usa (vea la sección 4).
- Cuántas veces usa Bless AI cada día.

### Actividad en la app (solo si inició sesión)

Guardamos, unido a su cuenta, lo que usted hace en la app. Por ejemplo, cuando usted:

- abre una pantalla;
- pone o para la radio (y una señal por cada minuto que escucha);
- abre un devocional;
- ora por un pedido;
- envía un mensaje a Bless AI o usa la voz;
- vota en una encuesta;
- toca "Donar";
- abre el contenido de emergencia.

Si no inició sesión, no guardamos esta actividad.

### Su progreso

Su racha (días seguidos), los devocionales y los días de planes de lectura que vio, su avance con los discípulos, las aventuras para niños, las noches en familia, sus logros, sus canciones favoritas, sus votos y los avisos que leyó.

### Si usa la app sin cuenta

Para evitar abusos, llevamos un contador de uso por día. Para eso guardamos solo un código hecho a partir de su dirección IP (un "hash" con sal). No guardamos la dirección IP.

### Micrófono

Usamos el micrófono solo cuando usted graba: un pedido de oración con audio, un saludo con audio o una conversación por voz con Bless AI. Su teléfono o su navegador le piden permiso antes.

### Lo que no recogemos

- Su ubicación. La ciudad es solo el texto que usted escribe.
- Sus contactos o su galería de fotos. Solo guardamos la foto de perfil que usted decida subir.
- Datos de salud o de dinero.

Pero lo que usted escribe o graba en un pedido, en un saludo o en Bless AI puede hablar de su fe, su salud o su familia. Comparta solo lo que quiera compartir.

### De dónde vienen sus datos

- De usted: lo que escribe, graba o elige.
- De su uso de la app: su actividad y su progreso.
- De Google o Apple, si entra con ellos.
- De su conexión, si usa la app sin cuenta: el código hecho a partir de su IP.

## 3. Para qué usamos sus datos

- Para darle el servicio: su cuenta, el mural, los saludos, Bless AI y su progreso.
- Para revisar los pedidos y cuidar el mural: aprobar, atender denuncias, bloquear y quitar contenido.
- Para evitar abusos, con límites de uso por día.
- Para ver cómo se usa la app, saber cuánto se escucha la radio y mejorar el servicio.
- Para responderle cuando nos escribe.
- Para cumplir la ley.

No usamos sus datos para publicidad.

## 4. Inteligencia artificial de otras empresas

Bless AI le permite conversar, por texto o por voz, con "discípulos": personajes bíblicos recreados con inteligencia artificial. Para funcionar, usa servicios de otras empresas:

- **OpenAI**, por medio de **Lovable AI Gateway** (un servicio de la empresa Lovable). Recibe sus mensajes y la conversación, para crear las respuestas. Recibe sus grabaciones de voz, para pasarlas a texto. Si usa la memoria pastoral, recibe sus conversaciones para crearla.
- **ElevenLabs.** Recibe el texto de las respuestas, para crear la voz de los discípulos.

También usamos OpenAI para narrar historias con voz. Para eso se envía el texto de la historia.

**Le pedimos permiso antes.** La primera vez que usa Bless AI, le explicamos esto y le preguntamos si acepta. Si no acepta, no enviamos sus mensajes ni su voz a estas empresas, y puede seguir usando el resto de la app.

**Memoria pastoral.** Es opcional. Si la usa, la IA guarda algunos datos sobre usted, sacados de sus conversaciones, para recordarlos después. En la app, solo usted puede verla. Nuestro equipo no puede leerla.

**Qué guardan estas empresas.** Les enviamos solo lo necesario para crear la respuesta, el texto o la voz. Cada empresa guarda y usa esos datos según su propia política de privacidad: OpenAI (https://openai.com/policies/privacy-policy), Lovable (https://lovable.dev/privacy) y ElevenLabs (https://elevenlabs.io/privacy-policy).

**Retirar su permiso.** Puede retirarlo cuando quiera en Más › Bless AI y privacidad, escribiéndonos a info@bless883fm.com o borrando su cuenta. Retirarlo no cambia lo que ya se envió antes.

## 5. Mural de oración: qué ven los demás

- Cada pedido se revisa antes de publicarse. Un moderador o un pastor de la radio lo aprueba.
- **Pedido público.** Después de aprobado, otros oyentes pueden ver el texto, la categoría, el nombre y la ciudad que usted escribió, el audio si lo grabó, su testimonio si lo agrega y las respuestas de los pastores. También pueden marcar que oraron por su pedido.
- **Pedido privado.** No aparece en el mural.
- **Pedido anónimo.** En lugar de su nombre y su ciudad, guardamos "Anónimo" y "Miami, FL". Otros oyentes nunca ven quién lo escribió. El pedido sigue unido a su cuenta, para que usted pueda marcarlo como respondido y para que se borre si borra su cuenta.
- **Cuidado:** el anonimato oculta su nombre y su ciudad, pero no lo que usted escribe ni su voz. Si su texto o su voz muestran quién es, otros pueden saber que es usted.
- Nuestro equipo (moderadores y pastores) puede leer los pedidos para revisarlos, orar y responder.
- Usted puede denunciar un pedido y bloquear a su autor. Si bloquea a alguien, ya no verá sus pedidos.

## 6. Con quién compartimos sus datos

Compartimos datos solo con empresas que nos ayudan a dar el servicio:

- **Lovable Cloud** (con tecnología de Supabase): guarda la base de datos, las cuentas y los archivos (fotos y audios).
- **Cloudflare:** aloja el servidor de la web y de la app.
- **Lovable:** publica el sitio web y cuenta las visitas al sitio de forma agregada (páginas vistas, país, tipo de dispositivo y de dónde llegó la visita).
- **Lovable AI Gateway y OpenAI:** Bless AI, memoria pastoral, voz a texto y texto a voz (vea la sección 4).
- **ElevenLabs:** la voz de los discípulos.
- **Google y Apple:** el inicio de sesión, solo si usted lo elige.
- **radio.co:** transmite la radio en vivo.
- **Stripe:** recibe las donaciones en su propia página, fuera de la app. La app no ve los datos de su tarjeta. Stripe usa sus datos según su propia política.
- **Spotify, iTunes Search (de Apple) y Deezer:** nuestro servidor les pide la lista de canciones y las portadas. Solo les envía el título y el artista de la canción, nunca datos suyos.

Como en cualquier servicio de internet, las empresas que alojan la app y transmiten la radio reciben datos técnicos de la conexión, como su dirección IP.

Exigimos a las empresas que reciben sus datos que los protejan igual o mejor que esta política.

También podemos entregar datos si la ley nos obliga, por ejemplo por orden de un juez.

No vendemos sus datos. No mostramos anuncios. No usamos herramientas de publicidad ni de seguimiento de otras empresas. No rastreamos lo que usted hace en otras apps ni en otros sitios web.

## 7. Cuánto tiempo guardamos sus datos

- Su cuenta, perfil, pedidos, oraciones, saludos, conversaciones, memoria pastoral y progreso: hasta que usted los borre o borre su cuenta.
- Su actividad en la app y cuántas veces usa Bless AI cada día: 180 días, o hasta que borre su cuenta, si la borra antes. Después solo guardamos el total de cada día (por ejemplo, cuántas personas escucharon la radio), sin nada que diga quién fue.
- El contador por día de quienes usan la app sin cuenta: 180 días. Después solo guardamos el total de cada día.
- Copias de seguridad: si nuestro proveedor de base de datos guarda copias automáticas, lo que usted borra puede quedar en ellas por un tiempo limitado, hasta que se reemplazan. No las usamos para nada más.
- Lo que guardan las empresas de inteligencia artificial: vea la sección 4.
- Si la ley nos obliga a guardar algo por más tiempo, lo guardamos solo para eso.

## 8. Cómo borrar su cuenta

Puede borrar su cuenta cuando quiera:

- **En la app:** en Más › Cuenta, toque "Eliminar mi cuenta".
- **En la web:** https://bless883fm.app/cuenta/eliminar

Al borrar su cuenta, borramos todos sus datos personales: perfil, pedidos, oraciones, saludos, conversaciones, memoria pastoral, actividad y progreso. También borramos sus fotos, sus audios y su acceso a la cuenta. Esto vale en todos sus dispositivos. No se puede deshacer.

Lo que pueda quedar en copias de seguridad se explica en la sección 7.

## 9. Seguridad

Cuidamos sus datos con medidas razonables. Por ejemplo:

- Su contraseña se guarda como un código (hash), no como texto que se pueda leer.
- En la app, solo usted puede ver su memoria pastoral. Nuestro equipo no puede leerla.
- Si usa la app sin cuenta, no guardamos su dirección IP.
- En los pedidos anónimos, no se guardan su nombre ni su ciudad reales.

Ningún sistema es 100 % seguro. Si un problema de seguridad afecta sus datos, le avisaremos cuando la ley lo exija. Usted también ayuda: use una contraseña segura y no la comparta.

## 10. Niños

La app no está dirigida a menores de 13 años. Tiene historias para niños, pensadas para escuchar en familia, con un adulto. No recogemos a sabiendas datos de menores de 13 años, y ellos no deben crear una cuenta.

Si usted es padre, madre o tutor y cree que su hijo nos dio datos, escríbanos a info@bless883fm.com. Borraremos la cuenta y sus datos.

## 11. Datos en otros países

Nuestros servidores y los de nuestros proveedores pueden estar en Estados Unidos o en otros países. Si usted vive fuera de Estados Unidos, sus datos se envían y se guardan fuera de su país. Allí las leyes de privacidad pueden ser distintas.

## 12. Sus derechos

Usted puede:

- **ver** sus datos y pedir una copia;
- **corregir** datos equivocados;
- **borrar** sus datos o su cuenta;
- **retirar su permiso**, por ejemplo para Bless AI.

Para hacerlo, borre su cuenta en la app o escríbanos a info@bless883fm.com. Podemos pedirle que confirme que es usted. Le responderemos en los plazos que fija la ley que le corresponde. No le trataremos distinto por usar sus derechos.

### Si vive en California

- Recogemos estas categorías de datos: identificadores (como su correo); lo que usted escribe o graba; su actividad en la app; y datos sensibles que usted decide compartir, como su fe o su salud.
- Vienen de las fuentes de la sección 2. Los usamos para lo que dice la sección 3 y los compartimos solo como dice la sección 6.
- No vendemos sus datos personales. Tampoco los compartimos para publicidad basada en su comportamiento.
- Usamos los datos sensibles solo para darle el servicio que usted pidió.
- Puede pedir saber qué datos tenemos, recibir una copia, corregirlos o borrarlos. Puede pedirlo usted o alguien que usted autorice.
- No compartimos sus datos con otras empresas para que le hagan publicidad.
- No rastreamos lo que usted hace en otros sitios ni en otras apps. Por eso, la señal "Do Not Track" (No rastrear) de su navegador no cambia nada.

### Si vive en Brasil o en la Unión Europea

- La responsable de sus datos es la radio (vea la sección 14).
- Usamos sus datos por estas razones (bases legales):
  - para darle lo que usted pide al usar la app (cuenta, mural, saludos, progreso);
  - con su consentimiento: Bless AI, la memoria pastoral y los datos sensibles que usted decide compartir, como su fe o su salud;
  - por nuestro interés legítimo en mantener la app segura y mejorarla: moderación, límites contra abusos y actividad en la app;
  - para cumplir la ley.
- También puede: recibir sus datos en un formato para llevarlos a otro servicio; oponerse a usos basados en nuestro interés legítimo; pedir que limitemos el uso de sus datos; y saber con quién los compartimos.
- Si no da su consentimiento para Bless AI, no podrá usarlo, pero sí el resto de la app.
- No tomamos decisiones automáticas que le afecten de forma importante. Una persona aprueba los pedidos del mural.
- Sus datos se tratan en Estados Unidos y en otros países (vea la sección 11).
- Puede presentar una queja ante la autoridad de protección de datos: en Brasil, la ANPD; en la Unión Europea, la de su país.

## 13. Cambios en esta política

Podemos cambiar esta política. Si el cambio es importante, le avisaremos en la app antes de que empiece a valer. Si cambiamos lo que enviamos a las empresas de inteligencia artificial, le pediremos permiso otra vez. Arriba verá la fecha de la versión vigente.

## 14. Contacto

- Genesis Radio Network, Inc.
- Dirección: 3401 SW 160th Avenue, Suite 403, Miramar, FL 33027, Estados Unidos
- Correo: info@bless883fm.com

En la app también encuentra nuestro correo y el teléfono pastoral.

---

# Bless 88.3 FM Privacy Policy

**Effective date:** October 14, 2026

This policy explains what data of yours we use, why we use it, and what you can do. It covers the Bless 88.3 FM app (iOS and Android) and the website bless883fm.app. Here we call both "the app."

## In short

- We do not sell your data.
- We do not show ads.
- We do not use advertising or tracking tools from other companies.
- We do not track what you do in other apps or on other websites.
- Before you use Bless AI for the first time, we ask for your permission, because your messages and your voice are sent to artificial intelligence companies.
- You can delete your account and your data in the app or on the web.

## 1. Who we are

Bless 88.3 FM is a Christian radio station in Miami, Florida (United States). The organization responsible for your data is:

- Genesis Radio Network, Inc.
- Address: 3401 SW 160th Avenue, Suite 403, Miramar, FL 33027, United States
- Email: info@bless883fm.com

In this policy, "we" means the radio station.

## 2. What data we collect and where it comes from

### Your account

- Your email and your password. Your password is stored as a code (hash) that no one can read.
- If you sign in with Google or Apple, they give us your email and an ID for your account.

### Your profile

- Your display name and your language.
- A photo, if you choose to upload one.
- The date you accepted the prayer wall rules.

### Prayer wall

- The text of your request and its category.
- Whether the request is public or private, and whether it is anonymous.
- The name and city you type in the request.
- The audio, if you record one.
- The prayers you make for other requests.
- Your testimonies, when you mark a request as answered.
- The reports and blocks you make.
- Any restrictions that moderators place on your account.

### Saludos (greetings to the studio)

- Your name, your city and your message, as text or audio.
- Saludos go to the station team in the studio. The host may read them or play them on the air.

### Bless AI

- The history of your conversations.
- Your pastoral memory, if you use it (see section 4).
- How many times you use Bless AI each day.

### Activity in the app (only when you are signed in)

We save what you do in the app, linked to your account. For example, when you:

- open a screen;
- start or stop the radio (and a signal for each minute you listen);
- open a devotional;
- pray for a request;
- send a message to Bless AI or use your voice;
- vote in a poll;
- tap "Donate";
- open the emergency content.

If you are not signed in, we do not save this activity.

### Your progress

Your streak (days in a row), the devotionals and reading-plan days you viewed, your progress with the disciples, kids' adventures, family nights, your achievements, your favorite songs, your votes and the notices you read.

### If you use the app without an account

To prevent abuse, we keep a daily usage counter. For this, we save only a code made from your IP address (a salted "hash"). We do not save your IP address.

### Microphone

We use the microphone only when you record: a prayer request with audio, a saludo with audio, or a voice conversation with Bless AI. Your phone or your browser asks for your permission first.

### What we do not collect

- Your location. The city is only the text you type.
- Your contacts or your photo gallery. We only save the profile photo you choose to upload.
- Health or financial data.

But what you write or record in a request, a saludo or Bless AI may talk about your faith, your health or your family. Share only what you want to share.

### Where your data comes from

- From you: what you write, record or choose.
- From your use of the app: your activity and your progress.
- From Google or Apple, if you sign in with them.
- From your connection, if you use the app without an account: the code made from your IP.

## 3. How we use your data

- To provide the service: your account, the prayer wall, saludos, Bless AI and your progress.
- To review requests and take care of the prayer wall: approve, handle reports, block and remove content.
- To prevent abuse, with daily usage limits.
- To see how the app is used, know how much the radio is heard, and improve the service.
- To answer you when you write to us.
- To comply with the law.

We do not use your data for advertising.

## 4. Artificial intelligence from other companies

Bless AI lets you talk, by text or by voice, with "disciples": Bible characters recreated with artificial intelligence. To work, it uses services from other companies:

- **OpenAI**, through the **Lovable AI Gateway** (a service of the company Lovable). It receives your messages and the conversation, to create the answers. It receives your voice recordings, to turn them into text. If you use pastoral memory, it receives your conversations to create it.
- **ElevenLabs.** It receives the text of the answers, to create the disciples' voices.

We also use OpenAI to narrate stories aloud. For this, the text of the story is sent.

**We ask for your permission first.** The first time you use Bless AI, we explain this and ask if you agree. If you do not agree, we do not send your messages or your voice to these companies, and you can keep using the rest of the app.

**Pastoral memory.** It is optional. If you use it, the AI saves some facts about you, taken from your conversations, to remember them later. In the app, only you can see it. Our team cannot read it.

**What these companies keep.** We send them only what is needed to create the answer, the text or the voice. Each company keeps and uses that data under its own privacy policy: OpenAI (https://openai.com/policies/privacy-policy), Lovable (https://lovable.dev/privacy) and ElevenLabs (https://elevenlabs.io/privacy-policy).

**Withdrawing your permission.** You can withdraw it at any time in More › Bless AI and privacy, by writing to us at info@bless883fm.com or by deleting your account. Withdrawing it does not change what was already sent.

## 5. Prayer wall: what others see

- Every request is reviewed before it is published. A moderator or a pastor of the station approves it.
- **Public request.** Once approved, other listeners can see the text, the category, the name and city you typed, the audio if you recorded one, your testimony if you add one, and the pastors' replies. They can also mark that they prayed for your request.
- **Private request.** It does not appear on the wall.
- **Anonymous request.** Instead of your name and city, we save "Anónimo" (Anonymous) and "Miami, FL". Other listeners never see who wrote it. The request stays linked to your account, so you can mark it as answered and so it is deleted if you delete your account.
- **Be careful:** being anonymous hides your name and city, but not what you write or your voice. If your text or your voice shows who you are, others may recognize you.
- Our team (moderators and pastors) can read requests to review them, pray and reply.
- You can report a request and block its author. If you block someone, you will no longer see their requests.

## 6. Who we share your data with

We share data only with companies that help us provide the service:

- **Lovable Cloud** (powered by Supabase): stores the database, the accounts and the files (photos and audio).
- **Cloudflare:** hosts the server for the website and the app.
- **Lovable:** publishes the website and counts visits to the site in aggregate (page views, country, device type and where the visit came from).
- **Lovable AI Gateway and OpenAI:** Bless AI, pastoral memory, speech to text and text to speech (see section 4).
- **ElevenLabs:** the disciples' voices.
- **Google and Apple:** sign-in, only if you choose it.
- **radio.co:** streams the live radio.
- **Stripe:** receives donations on its own page, outside the app. The app does not see your card details. Stripe uses your data under its own policy.
- **Spotify, iTunes Search (from Apple) and Deezer:** our server asks them for the song list and the album covers. It sends them only the song title and artist, never your data.

As with any internet service, the companies that host the app and stream the radio receive technical connection data, such as your IP address.

We require the companies that receive your data to protect it as well as or better than this policy does.

We may also hand over data if the law requires it, for example under a court order.

We do not sell your data. We do not show ads. We do not use advertising or tracking tools from other companies. We do not track what you do in other apps or on other websites.

## 7. How long we keep your data

- Your account, profile, requests, prayers, saludos, conversations, pastoral memory and progress: until you delete them or delete your account.
- Your activity in the app and how many times you use Bless AI each day: 180 days, or until you delete your account, if you do that first. After that, we keep only each day's total (for example, how many people listened to the radio), with nothing that shows who it was.
- The daily counter for people who use the app without an account: 180 days. After that, we keep only each day's total.
- Backups: if our database provider keeps automatic backups, what you delete may remain in them for a limited time, until they are replaced. We do not use them for anything else.
- What the AI companies keep: see section 4.
- If the law requires us to keep something longer, we keep it only for that reason.

## 8. How to delete your account

You can delete your account at any time:

- **In the app:** in More › Account, tap "Delete my account".
- **On the web:** https://bless883fm.app/cuenta/eliminar

When you delete your account, we delete all your personal data: profile, requests, prayers, saludos, conversations, pastoral memory, activity and progress. We also delete your photos, your audio and your sign-in account. This applies on all your devices. It cannot be undone.

Section 7 explains what may remain in backups.

## 9. Security

We protect your data with reasonable measures. For example:

- Your password is stored as a code (hash), not as text that can be read.
- In the app, only you can see your pastoral memory. Our team cannot read it.
- If you use the app without an account, we do not save your IP address.
- For anonymous requests, your real name and city are not saved.

No system is 100% secure. If a security problem affects your data, we will tell you when the law requires it. You can help too: use a strong password and do not share it.

## 10. Children

The app is not directed to children under 13. It has stories for children, meant to be heard as a family, with an adult. We do not knowingly collect data from children under 13, and they should not create an account.

If you are a parent or guardian and believe your child gave us data, write to us at info@bless883fm.com. We will delete the account and its data.

## 11. Data in other countries

Our servers and our providers' servers may be in the United States or in other countries. If you live outside the United States, your data is sent to and stored outside your country. Privacy laws there may be different.

## 12. Your rights

You can:

- **see** your data and ask for a copy;
- **correct** wrong data;
- **delete** your data or your account;
- **withdraw your permission**, for example for Bless AI.

To do this, delete your account in the app or write to us at info@bless883fm.com. We may ask you to confirm it is you. We will answer within the time limits set by the law that applies to you. We will not treat you differently for using your rights.

### If you live in California

- We collect these categories of data: identifiers (such as your email); what you write or record; your activity in the app; and sensitive data you choose to share, such as your faith or your health.
- They come from the sources in section 2. We use them as described in section 3 and share them only as described in section 6.
- We do not sell your personal information. We do not share it for advertising based on your behavior either.
- We use sensitive data only to provide the service you asked for.
- You can ask to know what data we have, to get a copy, to correct it or to delete it. You or someone you authorize can make the request.
- We do not share your data with other companies for their own marketing.
- We do not track what you do on other websites or in other apps. For this reason, your browser's "Do Not Track" signal does not change anything.

### If you live in Brazil or the European Union

- The station is responsible for your data (see section 14).
- We use your data for these reasons (legal bases):
  - to give you what you ask for when you use the app (account, prayer wall, saludos, progress);
  - with your consent: Bless AI, pastoral memory, and the sensitive data you choose to share, such as your faith or your health;
  - for our legitimate interest in keeping the app safe and improving it: moderation, abuse limits and activity in the app;
  - to comply with the law.
- You can also: receive your data in a format you can take to another service; object to uses based on our legitimate interest; ask us to limit the use of your data; and know who we share it with.
- If you do not consent to Bless AI, you cannot use it, but you can use the rest of the app.
- We do not make automated decisions that significantly affect you. A person approves prayer wall requests.
- Your data is processed in the United States and in other countries (see section 11).
- You can file a complaint with the data protection authority: in Brazil, the ANPD; in the European Union, the authority in your country.

## 13. Changes to this policy

We may change this policy. If the change is important, we will tell you in the app before it takes effect. If we change what we send to artificial intelligence companies, we will ask for your permission again. The date at the top shows the current version.

## 14. Contact

- Genesis Radio Network, Inc.
- Address: 3401 SW 160th Avenue, Suite 403, Miramar, FL 33027, United States
- Email: info@bless883fm.com

You can also find our email and our pastoral phone number in the app.
`,s=e();function c(){let{t:e,i18n:c}=n(),l=i(o,c.language);if(l.trim()&&!l.includes(`<PREENCHER`))return(0,s.jsxs)(`div`,{className:`px-5 pt-6 pb-10`,children:[(0,s.jsxs)(t,{to:`/mas`,className:`inline-flex items-center gap-1.5 text-[0.875rem] text-muted-foreground`,children:[(0,s.jsx)(r,{size:16}),` `,e(`deleteAccount.back`)]}),(0,s.jsx)(a,{text:l})]});let u=e(`aiConsent.privacySummary`,{returnObjects:!0});return(0,s.jsxs)(`div`,{className:`px-5 pt-6 pb-10`,children:[(0,s.jsxs)(t,{to:`/mas`,className:`inline-flex items-center gap-1.5 text-[0.875rem] text-muted-foreground`,children:[(0,s.jsx)(r,{size:16}),` `,e(`deleteAccount.back`)]}),(0,s.jsx)(`h1`,{className:`mt-4 font-brand text-[1.625rem] font-bold text-foreground`,children:e(`aiConsent.privacyTitle`)}),(0,s.jsx)(`h2`,{className:`mt-5 text-[0.9375rem] font-semibold text-foreground`,children:e(`aiConsent.privacyShort`)}),(0,s.jsx)(`ul`,{className:`mt-2 list-disc pl-5 space-y-1.5 text-[0.875rem] leading-relaxed text-muted-foreground`,children:u.map(e=>(0,s.jsx)(`li`,{children:e},e))}),(0,s.jsx)(t,{to:`/cuenta/eliminar`,className:`mt-6 inline-block text-[0.875rem] text-primary-ink underline`,children:e(`deleteAccount.pageTitle`)})]})}export{c as component};