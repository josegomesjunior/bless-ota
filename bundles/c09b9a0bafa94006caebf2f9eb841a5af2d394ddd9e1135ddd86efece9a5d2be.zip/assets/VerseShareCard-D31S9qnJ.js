const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/html2canvas-3k5U_Ryh.js","assets/chunk-QTnfLwEv.js"])))=>i.map(i=>d[i]);
import{r as e}from"./chunk-QTnfLwEv.js";import{n as t}from"./jsx-runtime-KLUqzItW.js";import{n,t as r}from"./createLucideIcon-Czsbm9hR.js";import{t as i}from"./preload-helper-zJ_50EbN.js";import{o as a}from"./native-_YdWLPAa.js";var o=r(`bookmark-check`,[[`path`,{d:`M17 3a2 2 0 0 1 2 2v15a1 1 0 0 1-1.496.868l-4.512-2.578a2 2 0 0 0-1.984 0l-4.512 2.578A1 1 0 0 1 5 20V5a2 2 0 0 1 2-2z`,key:`oz39mx`}],[`path`,{d:`m9 10 2 2 4-4`,key:`1gnqz4`}]]),s=r(`bookmark`,[[`path`,{d:`M17 3a2 2 0 0 1 2 2v15a1 1 0 0 1-1.496.868l-4.512-2.578a2 2 0 0 0-1.984 0l-4.512 2.578A1 1 0 0 1 5 20V5a2 2 0 0 1 2-2z`,key:`oz39mx`}]]),c=e(t(),1);function l(t){let{t:r}=n(),o=(0,c.useRef)(null),[s,l]=(0,c.useState)(!1);return{share:async()=>{l(!0);try{let n=document.createElement(`div`);n.style.position=`fixed`,n.style.left=`-10000px`,n.style.top=`0`,n.style.width=`1080px`,n.style.height=`1920px`,n.innerHTML=u(t,{label:r(`verseShare.etiqueta`),foot:r(`verseShare.pie`)}),document.body.appendChild(n);let{default:o}=await i(async()=>{let{default:t}=await import(`./html2canvas-3k5U_Ryh.js`).then(t=>e(t.default,1));return{default:t}},__vite__mapDeps([0,1])),s=await o(n,{width:1080,height:1920,scale:1,backgroundColor:null,useCORS:!0});document.body.removeChild(n),await a(await new Promise((e,t)=>s.toBlob(n=>n?e(n):t(Error(`no blob`)),`image/png`)),`bless-versiculo.png`,{title:r(`verseShare.tituloCompartir`),text:`"${t.text}" — ${t.ref}`})}catch(e){console.error(e)}finally{l(!1)}},isRendering:s,nodeRef:o}}function u(e,t){return`
    <div style="
      width:1080px;height:1920px;
      background: radial-gradient(ellipse at 30% 20%, #D42743 0%, #BF1A32 55%, #8F1024 100%);
      font-family: Georgia, 'Fraunces', serif;
      color: #fff;
      display:flex;flex-direction:column;justify-content:space-between;
      padding: 140px 110px;box-sizing:border-box;
      position:relative;
    ">
      <div style="display:flex;align-items:center;gap:16px;">
        <div style="width:14px;height:14px;border-radius:50%;background:#DBA207;"></div>
        <div style="font-family:Inter,system-ui,sans-serif;letter-spacing:8px;font-size:22px;font-weight:700;color:#F3CF7E;">BLESS 88.3 FM</div>
      </div>

      <div style="margin-top:80px;">
        <div style="font-family:Inter,system-ui,sans-serif;letter-spacing:6px;font-size:22px;font-weight:700;color:#F3CF7E;text-transform:uppercase;margin-bottom:60px;">${d(t.label)}</div>
        <div style="font-size:78px;line-height:1.18;font-style:italic;font-weight:400;">
          &ldquo;${d(e.text)}&rdquo;
        </div>
        <div style="margin-top:70px;font-size:44px;color:#F3CF7E;letter-spacing:2px;">
          ${d(e.ref)}
        </div>
      </div>

      <div style="display:flex;align-items:center;justify-content:space-between;font-family:Inter,system-ui,sans-serif;">
        <div style="font-size:26px;color:#F3CF7E;letter-spacing:3px;font-weight:600;">${d(t.foot)}</div>
        <div style="font-size:26px;color:rgba(255,255,255,0.85);">bless883.fm</div>
      </div>
    </div>
  `}function d(e){return e.replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e])}function f(){let[t,n]=(0,c.useState)(!1);return{share:async t=>{n(!0);try{let n=document.createElement(`div`);n.style.position=`fixed`,n.style.left=`-10000px`,n.style.top=`0`,n.style.width=`1080px`,n.style.height=`1920px`,n.innerHTML=p(t),document.body.appendChild(n);let{default:r}=await i(async()=>{let{default:t}=await import(`./html2canvas-3k5U_Ryh.js`).then(t=>e(t.default,1));return{default:t}},__vite__mapDeps([0,1])),o=await r(n,{width:1080,height:1920,scale:1,backgroundColor:null,useCORS:!0});document.body.removeChild(n),await a(await new Promise((e,t)=>o.toBlob(n=>n?e(n):t(Error(`no blob`)),`image/png`)),`bless-tesoro.png`,{title:t.lang===`en`?`Treasure verse · Bless 88.3 FM`:`Versículo tesoro · Bless 88.3 FM`,text:`"${t.text}" — ${t.ref}`})}catch(e){console.error(e)}finally{n(!1)}},isRendering:t}}function p(e){let t=e.lang===`en`?`TREASURE VERSE`:`VERSÍCULO TESORO`,n=e.lang===`en`?`MIAMI · LIVE`:`MIAMI · EN VIVO`;return`
    <div style="
      width:1080px;height:1920px;
      background: radial-gradient(ellipse at 30% 20%, #D42743 0%, #BF1A32 55%, #8F1024 100%);
      font-family: Georgia, 'Fraunces', serif;
      color:#fff;display:flex;flex-direction:column;justify-content:space-between;
      padding: 140px 110px;box-sizing:border-box;position:relative;
    ">
      <div style="display:flex;align-items:center;gap:16px;">
        <div style="width:14px;height:14px;border-radius:50%;background:#DBA207;"></div>
        <div style="font-family:Inter,system-ui,sans-serif;letter-spacing:8px;font-size:22px;font-weight:700;color:#F3CF7E;">BLESS 88.3 FM</div>
      </div>
      <div style="margin-top:60px;">
        <div style="font-family:Inter,system-ui,sans-serif;letter-spacing:6px;font-size:22px;font-weight:700;color:#F3CF7E;text-transform:uppercase;margin-bottom:44px;">${d(t)}</div>
        ${e.storyTitle?`<div style="font-family:Inter,system-ui,sans-serif;font-size:26px;font-weight:600;color:rgba(255,255,255,0.85);letter-spacing:2px;margin-bottom:30px;text-transform:uppercase;">${d(e.storyTitle)}</div>`:``}
        <div style="font-size:78px;line-height:1.18;font-style:italic;font-weight:400;">
          &ldquo;${d(e.text)}&rdquo;
        </div>
        <div style="margin-top:70px;font-size:44px;color:#F3CF7E;letter-spacing:2px;">
          ${d(e.ref)}
        </div>
      </div>
      <div style="display:flex;align-items:center;justify-content:space-between;font-family:Inter,system-ui,sans-serif;">
        <div style="font-size:26px;color:#F3CF7E;letter-spacing:3px;font-weight:600;">${d(n)}</div>
        <div style="font-size:26px;color:rgba(255,255,255,0.85);">bless883.fm</div>
      </div>
    </div>
  `}export{o as i,l as n,s as r,f as t};