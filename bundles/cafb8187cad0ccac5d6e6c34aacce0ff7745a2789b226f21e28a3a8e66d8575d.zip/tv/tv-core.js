/* Bless 88.3 FM na TV (change tv-web): lógica pura, sem tela. Roda no navegador da TV
   (sem módulos, JavaScript antigo) e no node:test. */
(function (raiz) {
  "use strict";

  var STREAM = "https://s4.radio.co/scb191562c/listen";
  var STATUS = "https://public.radio.co/stations/scb191562c/status";

  /* Minutos desde a meia-noite em Miami (America/New_York), sem depender do fuso da TV. */
  function minutosMiami(data) {
    try {
      var partes = new Intl.DateTimeFormat("en-US", {
        timeZone: "America/New_York", hour: "2-digit", minute: "2-digit", hourCycle: "h23"
      }).formatToParts(data);
      var h = 0, m = 0;
      for (var i = 0; i < partes.length; i++) {
        if (partes[i].type === "hour") h = parseInt(partes[i].value, 10) % 24;
        if (partes[i].type === "minute") m = parseInt(partes[i].value, 10);
      }
      return h * 60 + m;
    } catch (e) {
      /* TV sem fuso no Intl: Miami como UTC-5 (no horário de verão fica 1 h atrasado). */
      var utc = data.getUTCHours() * 60 + data.getUTCMinutes();
      return (utc - 300 + 1440) % 1440;
    }
  }

  function minutos(hhmm) {
    var p = String(hhmm || "").split(":");
    if (p.length < 2) return null;
    return parseInt(p[0], 10) * 60 + parseInt(p[1], 10);
  }

  function estaNoAr(show, agora) {
    var ini = minutos(show.start), fim = minutos(show.end);
    if (ini === null || fim === null) return false;
    if (fim === 0) fim = 1440;
    if (ini < fim) return agora >= ini && agora < fim;
    return agora >= ini || agora < fim; /* cruza a meia-noite */
  }

  function noAr(shows, data) {
    var agora = minutosMiami(data);
    for (var i = 0; i < (shows || []).length; i++) {
      if (estaNoAr(shows[i], agora)) return shows[i];
    }
    return null;
  }

  function proximo(shows, data) {
    var atual = noAr(shows, data);
    if (!atual) return null;
    var i = shows.indexOf(atual);
    return i >= 0 && i + 1 < shows.length ? shows[i + 1] : null;
  }

  function idioma(lang) {
    return String(lang || "").toLowerCase().indexOf("en") === 0 ? "en" : "es";
  }

  /* Música no ar, ou null quando o status traz o nome ou um anúncio da própria rádio. */
  function musica(status) {
    var t = status && status.current_track && status.current_track.title;
    t = String(t || "").replace(/^\s+|\s+$/g, "");
    if (!t) return null;
    var baixo = t.toLowerCase();
    if (baixo.indexOf("bless 88") === 0 || baixo.indexOf("bless88") >= 0) return null;
    return t;
  }

  function horaMiami(data) {
    var m = minutosMiami(data), h = Math.floor(m / 60), min = m % 60;
    var sufixo = h < 12 ? "AM" : "PM";
    var h12 = h % 12 === 0 ? 12 : h % 12;
    return h12 + ":" + (min < 10 ? "0" : "") + min + " " + sufixo;
  }

  var TV = {
    STREAM: STREAM, STATUS: STATUS, noAr: noAr, proximo: proximo, idioma: idioma,
    musica: musica, horaMiami: horaMiami, minutos: minutos
  };
  raiz.BlessTV = TV;
})(typeof window !== "undefined" ? window : this);
