/* Bless 88.3 FM na TV (change tv-web): tela, áudio e controle remoto. Samsung (Tizen), LG
   (webOS) e Fire TV com Vega OS abrem esta página pelo pacote da loja. JavaScript antigo de
   propósito (TVs de 2017 em diante): só var e function, sem módulos. */
(function () {
  "use strict";

  var TV = window.BlessTV;
  var AMBIENTE_APOS_MS = 30000;
  var REDESENHAR_A_CADA_MS = 15000;
  var lang = TV.idioma(navigator.language);
  var T = {
    pausar: lang === "en" ? "Pause" : "Pausar",
    escuchar: lang === "en" ? "Listen live" : "Escuchar en vivo",
    grade: lang === "en" ? "Schedule" : "Programación",
    hoy: lang === "en" ? "Today" : "Hoy",
    ambiente: lang === "en" ? "Ambient" : "Ambiente",
    aoVivo: lang === "en" ? "LIVE" : "EN VIVO",
    con: lang === "en" ? "with" : "con",
    sigue: lang === "en" ? "Up next" : "Sigue",
    bloqueado: lang === "en" ? "Press OK to start the radio." : "Pulsa OK para escuchar la radio.",
    oracao1: lang === "en" ? "Need prayer?" : "¿Necesitas oración?",
    oracao2: lang === "en" ? "Scan with your phone" : "Escanea con tu celular"
  };

  var audio = document.getElementById("radio");
  var botaoTocar = document.getElementById("botaoTocar");
  var tela = "tocando";
  var telaAntes = "tocando";
  var shows = [];
  var musicaAtual = null;
  var avplay = null;
  var tocandoAgora = false;
  var timerAmbiente = null;

  function $(id) { return document.getElementById(id); }

  // MARK: - Áudio

  /* Samsung: o player da TV não passa pela regra de autoplay do navegador. */
  function tocarAvplay() {
    if (!(window.webapis && window.webapis.avplay)) return false;
    try {
      avplay = window.webapis.avplay;
      avplay.open(TV.STREAM);
      avplay.prepareAsync(function () { avplay.play(); tocandoAgora = true; desenhar(); },
        function () { avplay = null; tocarAudio(); });
      return true;
    } catch (e) {
      avplay = null;
      return false;
    }
  }

  function tocarAudio() {
    audio.src = TV.STREAM + "?t=" + Date.now(); /* sempre o ponto ao vivo */
    var p = null;
    try { p = audio.play(); } catch (e) { mostrarBloqueio(); return; }
    if (p && p.then) {
      p.then(function () { tocandoAgora = true; esconderBloqueio(); desenhar(); })
        .catch(function () {
          /* A TV recusou som sem gesto: um OK no botão em foco liga a rádio. */
          mostrarBloqueio();
        });
    } else {
      tocandoAgora = true;
      desenhar();
    }
  }

  /* Ao abrir: tenta tocar com som, sem esperar tecla. Se a TV recusar som sem gesto,
     tocarAudio mostra o botão em foco e um OK liga a rádio. */
  function tocar() {
    if (tocarAvplay()) return;
    tocarAudio();
  }

  function pausar() {
    if (avplay) { try { avplay.stop(); avplay.close(); } catch (e) {} avplay = null; }
    audio.pause();
    audio.removeAttribute("src");
    tocandoAgora = false;
    desenhar();
  }

  function alternar() {
    if (tocandoAgora) pausar(); else tocar();
  }

  function mostrarBloqueio() {
    tocandoAgora = false;
    $("aviso").textContent = T.bloqueado;
    $("aviso").hidden = false;
    desenhar();
    focar(botaoTocar);
  }

  function esconderBloqueio() { $("aviso").hidden = true; }

  audio.addEventListener("pause", function () { if (!avplay) { tocandoAgora = false; desenhar(); } });
  audio.addEventListener("playing", function () { tocandoAgora = true; esconderBloqueio(); desenhar(); });

  // MARK: - Dados

  function pedir(url, ok) {
    var x = new XMLHttpRequest();
    x.open("GET", url, true);
    x.timeout = 10000;
    x.onload = function () {
      if (x.status === 200) { try { ok(JSON.parse(x.responseText)); } catch (e) {} }
    };
    x.send();
  }

  function atualizarDados() {
    pedir("/api/carro?lang=" + lang, function (d) {
      if (d && d.shows) {
        shows = d.shows;
        try { localStorage.setItem("bless.tv.shows", JSON.stringify(shows)); } catch (e) {}
        desenhar();
      }
    });
    pedir(TV.STATUS, function (s) { musicaAtual = TV.musica(s); desenhar(); });
  }

  function guardados() {
    try { return JSON.parse(localStorage.getItem("bless.tv.shows") || "[]"); } catch (e) { return []; }
  }

  // MARK: - Tela

  function nomes(show) {
    var h = show && show.hosts ? show.hosts : [];
    var n = [];
    for (var i = 0; i < h.length; i++) if (h[i] && h[i].name && h[i].name !== show.name) n.push(h[i].name);
    return n.join(", ");
  }

  function horario(show) { return String(show.start).slice(0, 5) + " – " + String(show.end).slice(0, 5); }

  function desenhar() {
    var agora = new Date();
    var atual = TV.noAr(shows, agora);
    var depois = TV.proximo(shows, agora);
    var locutores = atual ? nomes(atual) : "";
    $("programa").textContent = atual ? atual.name : "Bless 88.3 FM";
    $("detalhe").textContent = atual ? horario(atual) + (locutores ? " · " + T.con + " " + locutores : "") : "";
    $("musica").textContent = musicaAtual || "";
    $("seguinte").textContent = depois ? T.sigue + " " + String(depois.start).slice(0, 5) + " · " + depois.name : "";
    $("relogio").textContent = "Miami · " + TV.horaMiami(agora);
    botaoTocar.textContent = tocandoAgora ? T.pausar : T.escuchar;
    $("relogioAmbiente").textContent = TV.horaMiami(agora);
    $("programaAmbiente").textContent = atual ? atual.name + " · " + horario(atual) : "Bless 88.3 FM";
    $("musicaAmbiente").textContent = musicaAtual || T.aoVivo;
    /* Modo ambiente parado por horas marca TV OLED: muda um pouco de lugar. */
    var passo = Math.floor(Date.now() / 30000) % 4;
    $("ambienteConteudo").style.transform = "translate(" + (passo % 2) * 24 + "px," + Math.floor(passo / 2) * 16 + "px)";
    if (tela === "grade") desenharGrade(atual);
  }

  function desenharGrade(atual) {
    var lista = $("linhas");
    lista.innerHTML = "";
    for (var i = 0; i < shows.length; i++) {
      var li = document.createElement("li");
      li.className = "linha focavel" + (shows[i] === atual ? " aoVivo" : "");
      li.setAttribute("tabindex", "0");
      var hora = document.createElement("span"); hora.className = "hora"; hora.textContent = horario(shows[i]);
      var nome = document.createElement("span"); nome.className = "nome"; nome.textContent = shows[i].name;
      li.appendChild(hora); li.appendChild(nome);
      lista.appendChild(li);
    }
  }

  function mostrar(qual) {
    tela = qual;
    $("tocando").hidden = qual !== "tocando";
    $("grade").hidden = qual !== "grade";
    $("ambiente").hidden = qual !== "ambiente";
    desenhar();
    if (qual === "tocando") focar(botaoTocar);
    if (qual === "grade") { var l = document.querySelector(".linha.aoVivo") || document.querySelector(".linha"); if (l) focar(l); }
  }

  // MARK: - Foco e controle remoto

  var focadoAgora = null;

  function focar(el) {
    if (!el) return;
    if (focadoAgora) focadoAgora.className = focadoAgora.className.replace(/\s*focado/g, "");
    focadoAgora = el;
    el.className += " focado";
    if (el.focus) el.focus();
    if (el.scrollIntoView && tela === "grade") el.scrollIntoView(false);
  }

  /* Foco espacial: o elemento visível mais próximo na direção da seta. */
  function moverFoco(dx, dy) {
    var itens = document.querySelectorAll(".tela:not([hidden]) .focavel");
    if (!focadoAgora) { focar(itens[0]); return; }
    var a = focadoAgora.getBoundingClientRect();
    var ax = a.left + a.width / 2, ay = a.top + a.height / 2;
    var melhor = null, menor = Infinity;
    for (var i = 0; i < itens.length; i++) {
      if (itens[i] === focadoAgora) continue;
      var b = itens[i].getBoundingClientRect();
      var bx = b.left + b.width / 2, by = b.top + b.height / 2;
      var vx = bx - ax, vy = by - ay;
      if ((dx > 0 && vx <= 0) || (dx < 0 && vx >= 0) || (dy > 0 && vy <= 0) || (dy < 0 && vy >= 0)) continue;
      var d = Math.abs(vx) + Math.abs(vy) * (dx !== 0 ? 3 : 1) + Math.abs(vx) * (dy !== 0 ? 3 : 0);
      if (d < menor) { menor = d; melhor = itens[i]; }
    }
    if (melhor) focar(melhor);
  }

  function armarAmbiente() {
    if (timerAmbiente) clearTimeout(timerAmbiente);
    timerAmbiente = setTimeout(function () {
      if (tela !== "ambiente") { telaAntes = tela; mostrar("ambiente"); }
    }, AMBIENTE_APOS_MS);
  }

  function sairDoAmbiente() { mostrar(telaAntes); }

  function ativar(el) {
    if (el === botaoTocar) alternar();
    else if (el === $("botaoGrade")) mostrar("grade");
    else if (el === $("botaoAmbiente")) { telaAntes = tela; mostrar("ambiente"); }
    else if (el && el.className.indexOf("linha") >= 0) mostrar("tocando");
  }

  function aoTeclar(e) {
    armarAmbiente();
    if (tela === "ambiente") {
      sairDoAmbiente();
      return;
    }
    var k = e.keyCode;
    /* Mídia: Tizen 10252 (play/pausa); Tizen e webOS 415 (play) e 19 (pausa). */
    if (k === 10252 || k === 179) { alternar(); e.preventDefault(); return; }
    if (k === 415) { if (!tocandoAgora) alternar(); e.preventDefault(); return; }
    if (k === 19) { if (tocandoAgora) pausar(); e.preventDefault(); return; }
    /* Voltar: Tizen 10009, webOS 461, navegador 8. */
    if (k === 10009 || k === 461 || k === 8) {
      if (tela === "grade") { mostrar("tocando"); e.preventDefault(); }
      return;
    }
    if (k === 37) { moverFoco(-1, 0); e.preventDefault(); return; }
    if (k === 39) { moverFoco(1, 0); e.preventDefault(); return; }
    if (k === 38) { moverFoco(0, -1); e.preventDefault(); return; }
    if (k === 40) { moverFoco(0, 1); e.preventDefault(); return; }
    if (k === 13) { ativar(focadoAgora); e.preventDefault(); }
  }

  /* Samsung: as teclas de mídia só chegam à página depois de registradas. */
  function registrarTeclas() {
    try {
      var nomesTeclas = ["MediaPlayPause", "MediaPlay", "MediaPause"];
      for (var i = 0; i < nomesTeclas.length; i++) window.tizen.tvinputdevice.registerKey(nomesTeclas[i]);
    } catch (e) {}
  }

  // MARK: - Início

  window.onload = function () {
    $("seloAoVivo").textContent = T.aoVivo;
    $("botaoGrade").textContent = T.grade;
    $("botaoAmbiente").textContent = T.ambiente;
    $("tituloGrade").textContent = T.grade + " · " + T.hoy;
    $("convite1").textContent = T.oracao1;
    $("convite2").textContent = T.oracao2;
    document.documentElement.lang = lang;
    shows = guardados();
    registrarTeclas();
    document.addEventListener("keydown", aoTeclar);
    /* Ponteiro do Magic Remote (LG) e mouse: clicar ativa o elemento. */
    document.addEventListener("click", function (e) {
      var el = e.target;
      while (el && el.className && String(el.className).indexOf("focavel") < 0) el = el.parentNode;
      if (el && el.className) { focar(el); ativar(el); }
      armarAmbiente();
    });
    mostrar("tocando");
    tocar();
    atualizarDados();
    setInterval(function () { atualizarDados(); }, REDESENHAR_A_CADA_MS * 4);
    setInterval(desenhar, REDESENHAR_A_CADA_MS);
    armarAmbiente();
  };
})();
